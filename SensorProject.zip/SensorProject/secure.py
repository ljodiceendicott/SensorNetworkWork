import cv2
import numpy as np
from datetime import datetime, timedelta

def get_datetime():
    t = datetime.now()
    return t.strftime("%b-%d-%Y_%I-%M")

def setup_cap():
    return cv2.VideoCapture(0)

# duration: how long the video lasts for in seconds
def setup_video(cap, duration=5):
    out = cv2.VideoWriter('evidence\\video\\'+ str(get_datetime())+'-evidence.mp4',cv2.VideoWriter_fourcc(*'mp4v'), 30, (int(cap.get(3)), int(cap.get(4))))
    # adding seconds to time
    # https://stackoverflow.com/questions/6205442/how-to-find-datetime-10-mins-after-current-time
    now = datetime.now()
    future = now + timedelta(seconds=duration)

    while now < future:
        ret, frame = cap.read()
        if ret:
            out.write(frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        now = datetime.now()

    out.release()
    cap.release()

    return True

def take_photo(cap, x):
    ret,frame = cap.read()
    file_name = "evidence\\photo\\"+ str(get_datetime())+"-evidence"+str(x)+".png"
    cv2.imwrite(file_name,frame)
    # cap.release()
