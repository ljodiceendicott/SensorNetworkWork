import serial
from serial.tools import list_ports
import sys
import time
import secure

# TODO: Make searching serial port cross-platform compatiable
arduino = None

def search_arduino(pid):
    ports = list_ports.comports()
    
    if pid > -1:
        for p in ports:
            if p.pid == pid:
                return p.name
    else:
        print("CONNECTED PORTS")
        i = 0
        for p in ports:
            print(" > ", i, p.name)
            i += 1
        user_input = int(input("Select number that is associated with the Arduino device: "))
        port = ports[user_input]
        if user_input >= len(ports) or port.pid == None or port.vid == None:
            print("Either input is out of bounds or PID or VID do not exist.")
        else:
            return port.device
    
    print("Cannot find connected Arduino device. Check if it is plugged.")
    exit(1)

# range_max: Limit to the distance Python should trigger the security
def sensor(set_photo, range_max=100):
    keep_reading = True
    obj_spotted = False

    margin = 10
    size_limit = 10
    index = 0
    detects = [None] * size_limit

    print("Detector enabling in 7 seconds...")
    time.sleep(7)
    while keep_reading:
        data = arduino.read()
        data = int.from_bytes(data, byteorder='little')

        if data > 0 and data <= range_max:
            detects[index] = data
            index += 1

            if index >= size_limit:
                index = 0
                for i in range(1, size_limit):
                    if abs(detects[i] - detects[i - 1]) >= margin:
                        # if there is a spike in difference,
                        # an object was detected within the range
                        obj_spotted = True
                        break

        if obj_spotted:
            
            cap_video = secure.setup_cap()
            secure.setup_video(cap_video)
            if set_photo:
                cap_photo = secure.setup_cap()
                for i in range(5):
                    secure.take_photo(cap_photo, i)
                    print("Photo Taken")
            obj_spotted = False
            #keep_reading = False
        
        time.sleep(0.25)

    arduino.close()

def main():
    global arduino

    pid = -1
    if len(sys.argv) > 1:
        pid = int(sys.argv[1])
    port_name = search_arduino(pid)
    arduino = serial.Serial(port_name, baudrate=9600, timeout=0.3)

    arduino.reset_input_buffer()
    arduino.reset_output_buffer()

    keep_program = True
    while keep_program:
        print("SECURITY 101")
        print(" > 2 - Enable radius detector")
        print("      -v,--video start video mode")
        print("      -p,--photo start photo mode")

        print("\n > 0 - Exit")
        print(" > 1 - Help")
        user_input = input("Select option: ")
        args = user_input.split(" ")
        cmd = int(args[0])

        if cmd == 0:
            keep_program = False
        elif cmd == 1:
            print("\n- - - - HELP - - - -\n")
            # Ignore atrocious formatting
            # I needed multi-line printing
            print(
                """
    2 - Enables nearby object detector. When an object is within the proximity,
        the camera will be turned on and track for a human body.

            --range=<num>
                Maximum distance (in cm) where the sensor will alarm the security.
                Default is 100 if none is provided
            -v, --video
                Enable video capturing 
            -p, --photo
                Enable photo capturing
                """
            )
           
        elif cmd == 2:
            arg_range = 100
            arg_photo = False

            i = 1
            while i < len(args):
                arg = args[i]
                if arg == "--range":
                    arg_range = int(args[i + 1])
                    i += 1
                elif arg == "-p" or arg == "--photo":
                    arg_photo = True

                i += 1
            sensor(arg_photo, arg_range)

if __name__ == "__main__":
    main()