# Sensor Networks Project

Ultrasonic Sensor Circuit Diagram:
[Link to Ultrasonic Sensor Circuit Diagram](https://www.tinkercad.com/things/0ov2Xpc12td-terrific-kup/editel?sharecode=985gN-PDw-EBN6Eih924M_OU6oy1N88lfXpUFh5FMWQ)
![Circuit Diagram](/images/circuit_diagram.png)
