import google.auth

credentials, project = google.auth.default()